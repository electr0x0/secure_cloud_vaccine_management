from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from core.database import get_db
from core import auth
from core.models.models import User, VaccinationType, VaccinationHistory
from core.models import schemas

router = APIRouter()

@router.get("/history", response_model=schemas.VaccinationFullHistoryResponse)
def get_vaccination_history(email: str, db: Session = Depends(get_db)):
    try:
        # First, verify the email exists in the users table
        user = db.query(User).filter(User.email == email).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Get all vaccination records for the user
        vaccination_records = (
            db.query(VaccinationHistory)
            .filter(VaccinationHistory.user_email == email)
            .all()
        )

        # Get all vaccine types for reference
        vaccine_types = {
            vt.id: vt for vt in db.query(VaccinationType).all()
        }

        # Format the response
        vaccination_history = []
        for record in vaccination_records:
            vaccine_type = vaccine_types.get(record.vaccine_type_id)
            if vaccine_type:
                vaccination_history.append(
                    schemas.VaccinationEntry(
                        vaccine_name=vaccine_type.vaccine_name,
                        vaccine_code=vaccine_type.vaccine_code,
                        dose_number=record.dose_number,
                        vaccination_date=record.vaccination_date,
                        vaccinator_email=record.vaccinator_email,
                        notes=record.notes,
                    )
                )

        return schemas.VaccinationFullHistoryResponse(
            vaccination_history=vaccination_history
        )

    except Exception as e:
        raise

@router.post("/history")
def update_vaccination_history(
    payload: schemas.VaccinationEntryCreate,
    db: Session = Depends(get_db),
):
    try:
        # Verify vaccinator authentication and authorization
        vaccinator = db.query(User).filter(User.email == payload.vaccinator_email).first()
        if not vaccinator or vaccinator.user_type != "vaccinator":
            raise HTTPException(
                status_code=403, detail="Unauthorized or invalid vaccinator"
            )

        # Verify patient exists
        patient = db.query(User).filter(User.email == payload.patient_email).first()
        if not patient:
            raise HTTPException(status_code=404, detail="Patient not found")

        # Get vaccine type
        vaccine_type = (
            db.query(VaccinationType)
            .filter(VaccinationType.vaccine_code == payload.vaccine_code)
            .first()
        )
        if not vaccine_type:
            raise HTTPException(status_code=404, detail="Invalid vaccine type")

        # Check if this dose already exists
        existing_dose = (
            db.query(VaccinationHistory)
            .filter(
                VaccinationHistory.user_email == payload.patient_email,
                VaccinationHistory.vaccine_type_id == vaccine_type.id,
                VaccinationHistory.dose_number == payload.dose_number,
            )
            .first()
        )

        if existing_dose:
            raise HTTPException(
                status_code=400,
                detail=f"Dose {payload.dose_number} of {payload.vaccine_code} already recorded",
            )

        # Check if the dose number is valid (sequential)
        max_existing_dose = (
            db.query(VaccinationHistory.dose_number)
            .filter(
                VaccinationHistory.user_email == payload.patient_email,
                VaccinationHistory.vaccine_type_id == vaccine_type.id,
            )
            .order_by(VaccinationHistory.dose_number.desc())
            .first()
        )

        if max_existing_dose:
            if payload.dose_number != max_existing_dose[0] + 1:
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid dose number. Expected dose {max_existing_dose[0] + 1}",
                )
        elif payload.dose_number != 1:
            raise HTTPException(
                status_code=400, detail="First dose must have dose number 1"
            )

        # Check if maximum doses exceeded
        if payload.dose_number > vaccine_type.max_doses:
            raise HTTPException(
                status_code=400,
                detail=f"Maximum doses ({vaccine_type.max_doses}) exceeded for {payload.vaccine_code}",
            )

        # Create vaccination record
        vaccination_record = VaccinationHistory(
            user_email=payload.patient_email,
            vaccine_type_id=vaccine_type.id,
            dose_number=payload.dose_number,
            vaccination_date=payload.vaccination_date,
            vaccinator_email=payload.vaccinator_email,
            notes=payload.notes,
        )

        db.add(vaccination_record)
        db.commit()

        return {"message": "Vaccination record added successfully"}

    except Exception as e:
        raise

@router.post("/stats")
def get_vaccination_stats(jwt: schemas.TokenInput, db: Session = Depends(get_db)):
    try:
        # Get all vaccination records
        vaccination_records = db.query(VaccinationHistory).all()
        
        # Get all vaccine types
        vaccine_types = db.query(VaccinationType).all()
        
        # Calculate statistics
        stats = {
            "total_vaccinations": len(vaccination_records),
            "vaccine_type_distribution": {},
            "dose_distribution": {}
        }
        
        for vt in vaccine_types:
            stats["vaccine_type_distribution"][vt.vaccine_code] = 0
            
        for record in vaccination_records:
            vaccine_code = next(
                (vt.vaccine_code for vt in vaccine_types if vt.id == record.vaccine_type_id),
                None
            )
            if vaccine_code:
                stats["vaccine_type_distribution"][vaccine_code] += 1
                
            dose_key = f"dose_{record.dose_number}"
            stats["dose_distribution"][dose_key] = stats["dose_distribution"].get(dose_key, 0) + 1

        return stats

    except Exception as e:
        raise 